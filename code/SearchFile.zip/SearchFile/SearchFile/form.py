from django import forms
from django.forms import fields
from django.forms import widgets


class SearchForm(forms.Form):
	key = forms.CharField(label='key word',max_length=25, required = True)
	
class SearchOneForm(forms.Form):
	name = forms.CharField(label='file name',max_length=100, required = True)
	key = forms.CharField(label='key word',max_length=25, required = False)
	
