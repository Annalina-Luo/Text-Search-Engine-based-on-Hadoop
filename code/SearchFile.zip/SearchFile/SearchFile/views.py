from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from .form import SearchForm, SearchOneForm
import mysql.connector

def home(request):
	if request.method == 'POST':
		key = ''
		form = SearchForm(request.POST or None)
		if form.is_valid():
			key = form.cleaned_data.get("key")

			connection = mysql.connector.connect(host="localhost",
                                         user="root",
                                         passwd="1830001064",
                                         db="ws2",
                                         auth_plugin='mysql_native_password',
                                         use_pure=True)
			cursor = connection.cursor()
			sql_command1 = "SELECT time, article FROM ws2.record WHERE word like \'"+ key +"\' LIMIT 0,50"
			cursor.execute(sql_command1)
			items = cursor.fetchall()
			cursor.close()
			connection.close()
			if len(items) == 0:
				message = 'No file has this key word!'+'\n'
				return render(request, "home.html", {'form': form, 'message': message})
			else:
				return render(request,"home.html",{'form': form, 'files':items})
	else:
		form = SearchForm()
		return render(request,"home.html",{'form': form})
		
def one(request):
	if request.method == 'POST':
		key = ''
		name = ''
		form = SearchOneForm(request.POST or None)
		if form.is_valid():
			name = form.cleaned_data.get("name")
			key = form.cleaned_data.get("key")
			name = name.replace(" ","_")
			connection = mysql.connector.connect(host="localhost",
                                         user="root",
                                         passwd="1830001064",
                                         db="ws2",
                                         auth_plugin='mysql_native_password',
                                         use_pure=True)
			cursor = connection.cursor()
			if key == '':
				sql_command1 = "SELECT time, word FROM ws2.record WHERE article like \'"+ name +"%\' ORDER BY time DESC LIMIT 0,50"
			else:
				sql_command1 = "SELECT time, word FROM ws2.record WHERE article like \'"+ name +"%\' and word like \'"+ key +"\'"
			cursor.execute(sql_command1)
			items = cursor.fetchall()
			cursor.close()
			connection.close()
			if len(items) == 0:
				message = 'No file has this key word!'+'\n'
				return render(request, "one.html", {'form': form, 'message': message})
			else:
				return render(request,"one.html",{'form': form, 'files':items})
	else:
		form = SearchOneForm()
		return render(request,"one.html",{'form': form})

		
@csrf_exempt #增加装饰器，作用是跳过 csrf 中间件的保护		
def content(request):
	name = request.GET.get("name")
	filename = name
	name = name.replace("_xc3xadxc2xac_","%")
	name = name.replace("xc3xab","%")
	name = name.replace("xc2xaa","%")
	name = name.replace("xc3xa7ois","%")
	name = name.replace("xc2xbf","%")
	
	connection = mysql.connector.connect(host="localhost",
                                         user="root",
                                         passwd="1830001064",
                                         db="ws2",
                                         auth_plugin='mysql_native_password',
                                         use_pure=True)
	cursor = connection.cursor()
	sql_command1 = "SELECT content FROM ws2.articles WHERE name like \'%"+ name +"%\'"
	cursor.execute(sql_command1)
	content = cursor.fetchone()
	content = list(content)
	content = content[0]
	cursor.close()
	connection.close()
	if request.method == 'POST':
		path = ".\\"+filename
		f = open(path, "w+", encoding='utf-8')
		f.write(content)
		f.close()
		message = "Download Successfully!"
		return render(request,"content.html",{'content': content, 'message':message})
	else:
		return render(request,"content.html",{'content': content})